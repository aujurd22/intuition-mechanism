#Convert a class polynomial for X_0^+(119) with variables x,y into one with variables w,x,z (see Example 7.4 in the paper)

R4.<x,y> = QQ[]
P.<x,y,w,z> = QQ[]
def g(f):
  f = P(R4(f))
  f = f(x,z-x,w,z) # get rid of y
  while True:
    old = f
    c = f.coefficients()
    m = f.exponents()
    n = len(c)
    f = sum([c[i]*x^(m[i][0] % 2)*(w+z)^(floor(m[i][0] / 2))*w^m[i][2]*z^m[i][3] for i in range(n)]) # get rid of x^2
    assert (old(x,y,-y+x^2-x,y+x) - f(x,y,-y+x^2-x,y+x)) / (y^2+3*x*y-y-x^3+3*x^2-x) in P
    c = f.coefficients()
    m = f.exponents()
    n = len(c)
    f = sum([c[i]*x^m[i][0]*w^m[i][2]*z^(m[i][3] % 2)*(x^3-x^2-x*z+z)^floor(m[i][3] / 2) for i in range(n)]) # get rid of z^2
    assert (old(x,y,-y+x^2-x,y+x) - f(x,y,-y+x^2-x,y+x)) / (y^2+3*x*y-y-x^3+3*x^2-x) in P
    if f == old:
        return f