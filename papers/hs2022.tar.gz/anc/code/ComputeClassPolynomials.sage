#Upon input of N\in\{119,191,239\}, a fraction of the maximum LLL-precision, a range of discriminants, and a range of class numbers, we compute the generalized class polynomial for all fundamental discriminants of prime class number within these bounds.

N = eval(input("N = "))

lowdisc = -eval(input("Lowest discriminant = "))
highdisc = -eval(input("Highest discriminant = "))
discrange = range(lowdisc,highdisc,-1)

lowclass = eval(input("Lowest class number = "))
highclass = eval(input("Highest class number = "))

LLLper = eval(input("Percent of maximum LLL-precision = "))

filestr = 'd8ta'+str(N)+'t'+str(LLLper)+'h'+str(lowclass)+'-'+str(highclass)+'D'+str(-lowdisc)+'-'+str(-highdisc)+'.txt'

firstline = 'Class polynomials for N = '+str(N)+' at '+str(LLLper)+'% for prime class numbers in '+str([lowclass,highclass])+' for fundamental discriminants in '+str([-lowdisc,-highdisc])+' with optimized functions:'+'\n'


if N == 119:
	bitp = 20000
	C = ComplexField(bitp)
	I = C.gen()
	K.<q> = Frac(QQ[['q']])
	R2.<r,s> = PolynomialRing(QQ)

	bigo = 2600
	load("xy2600.sage") #load the q-expansion of x and y

	qexp_y = -qexp_y-2*qexp_x

	#function to find a ZZ-relation using a single q
	def findzzrelmanual(h,qspec,xp,yp,t):
		maplist = [r^0]
		for j in range(floor(h/2)+1):
			maplist += [r^(j+1),r^j*s]
		del maplist[h+1:]
		qrslist = [m(xp,yp) for m in maplist]
		A = Matrix(ZZ,[[int(i==j) for i in range(h+1)]+[round(10^t*real(qrslist[j])),round(10^t*imag(qrslist[j]))] for j in range(h+1)])
		shortvector = A.LLL()[0]
		zzrel = vector(QQ,shortvector[:h+1]).inner_product(vector(R2,maplist))
		error = shortvector[-2:]
		return zzrel,error

	#function to find a ZZ-relation using a single (the highest) tau
	def disctopolysingle(D,t):
		assert D<0 and (D%4==0 or D%4==1)
		assert gcd(N,D)==1 and Zmod(N)(D).is_square()
		d = D.squarefree_part()
		if d%4==3 or d%4==2:
			d*=4
		u = sqrt(D/d)
		o = ZZ[u*(d+sqrt(d))/2]
		h = o.class_number()
		a = 1
		b = ZZ(Zmod(4*a*N)(D).sqrt())
		c = (b^2-D)/4
		KK.<delta> = QuadraticField(D)
		sqrtD = KK(D).sqrt()
		alpha = (-b + sqrtD)/(2*a)
		tau = alpha/N
		qspec = C(exp(2*pi*I*tau))
		xp = (qexp_x.laurent_polynomial())(qspec)
		yp = (qexp_y.laurent_polynomial())(qspec)
		zzrel,error = findzzrelmanual(h,qspec,xp,yp,t)
		return [h,u,D,zzrel,error,t]

	#function to compute the "improvement factor" for a given D and LLL-precision t
	def compare(D,t):
		data = disctopolysingle(D,t)
		h = data[0]
		class_polynomial = data[3]
		maxhilbert = max([abs(hilbert_class_polynomial(D)[i]) for i in range(h+1)])
		maxclass = max([abs(i[0]) for i in list(class_polynomial)]+[2]) # +[2] to make sure we don't divide by zero
		improvementfactor = n(log(maxhilbert)/log(maxclass),20)
		return data+[improvementfactor]

	#function to estimate tail of the q-expansion
	def guesserror(tau):
		qspec = C(exp(2*pi*I*tau))
		guess = n(max(abs(sum([qexp_x[i]*qspec^i for i in range(floor(bigo*0.95),bigo-1)])),abs(sum([qexp_y[i]*qspec^i for i in range(floor(bigo*0.95),bigo-1)]))),50)
		return guess

	#combination of the above two functions to estimate the maximum LLL-precision t when using a single tau
	def maxt(D):
		assert D<0 and (D%4==0 or D%4==1)
		assert gcd(N,D)==1 and Zmod(N)(D).is_square()
		d = D.squarefree_part()
		if d%4==3 or d%4==2:
			d*=4
		u = sqrt(D/d)
		O = ZZ[u*(d+sqrt(d))/2]
		h = O.class_number()
		a = 1
		b = ZZ(Zmod(4*a*N)(D).sqrt())
		c = (b^2-D)/4
		KK.<delta> = QuadraticField(D)
		sqrtD = KK(D).sqrt()
		alpha = (-b + sqrtD)/(2*a)
		tau = alpha/N
		qspec = C(exp(2*pi*I*tau))
		knownbits = min(floor(log(1/guesserror(tau))/log(2)),bitp) #assumes implicitly that x and y have modulus at least one
		largestterm = log(max(abs((qexp_x.laurent_polynomial())(qspec)^(h/2)),1)*max(abs((qexp_y.laurent_polynomial())(qspec)),1))/log(2) #bit size of largest monomial (excluding coefficient) in the class polynomial
		diff = knownbits - largestterm
		return floor(LLLper/100*diff*log(2)/log(10))

if N == 191:
	fb = Newforms(N,names='b')[0]
	F = fb.base_ring()
	V, fromV, toV = F.vector_space()
	bigo = 10000
	qsage = [list(toV(fb[i])) for i in range(bigo+1)]
	K.<q> = Frac(QQ[['q']])
	f=O(q^bigo)
	g=O(q^bigo)
	for i in range(bigo+1):
		f=f+(2*qsage[i][0]-qsage[i][1])*q^i
		g=g+(-qsage[i][1])*q^i
	X = f/g;    
	Y = q*derivative(X,q)/g
	bitp = 20000
	C = ComplexField(bitp)
	I = C.gen()
	qexp_x = (-(X-1)/2).laurent_polynomial()
	qexp_y = (-Y/2).laurent_polynomial()

	R1.<x0,y0> = PolynomialRing(QQ)
	Q = (y0+x0^3+x0+1)/2
	R = x0*Q
	S = x0*(R+1)-Q

	R2.<x1,x2,x3> = PolynomialRing(QQ)

	#function to find a ZZ-relation using a single q
	def findzzrelmanual(h,qspec,xp,yp,t):
		maplist = [x1^0]
		for j in range(floor(h/3)+1):
			maplist += [x1^(j+1),x1^j*x2,x1^j*x3]
		del maplist[h+1:]
		Qeval = Q(xp,yp)
		Reval = R(xp,yp)
		Seval = S(xp,yp)
		qrslist = [m(Qeval,Reval,Seval) for m in maplist]
		A = Matrix(ZZ,[[int(i==j) for i in range(h+1)]+[round(10^t*real(qrslist[j])),round(10^t*imag(qrslist[j]))] for j in range(h+1)])
		shortvector = A.LLL()[0]
		zzrel = vector(QQ,shortvector[:h+1]).inner_product(vector(R2,maplist))
		error = shortvector[-2:]
		return zzrel,error

	#function to find a ZZ-relation using a single (the highest) tau
	def disctopolysingle(D,t):
		assert D<0 and (D%4==0 or D%4==1)
		assert gcd(N,D)==1 and Zmod(N)(D).is_square()
		d = D.squarefree_part()
		if d%4==3 or d%4==2:
			d*=4
		u = sqrt(D/d)
		o = ZZ[u*(d+sqrt(d))/2]
		h = o.class_number()
		a = 1
		b = ZZ(Zmod(4*a*N)(D).sqrt())
		c = (b^2-D)/4
		KK.<delta> = QuadraticField(D)
		sqrtD = KK(D).sqrt()
		alpha = (-b + sqrtD)/(2*a)
		tau = alpha/N
		qspec = C(exp(2*pi*I*tau))
		xp = qexp_x(qspec)
		yp = qexp_y(qspec)
		zzrel,error = findzzrelmanual(h,qspec,xp,yp,t)
		return [h,u,D,zzrel,error,t]

	#function to compute the "improvement factor" for a given D and LLL-precision t
	def compare(D,t):
		data = disctopolysingle(D,t)
		h = data[0]
		class_polynomial = data[3]
		maxhilbert = max([abs(hilbert_class_polynomial(D)[i]) for i in range(h+1)])
		maxclass = max([abs(i[0]) for i in list(class_polynomial)]+[2]) # +[2] to make sure we don't divide by zero
		improvementfactor = n(log(maxhilbert)/log(maxclass),20)
		return data+[improvementfactor]

	#function to estimate tail of the q-expansion of Xp
	def guesserror(tau):
		qspec = C(exp(2*pi*I*tau))
		guess = n(max(abs(sum([qexp_x[i]*qspec^i for i in range(floor(bigo*0.95),bigo-1)])),abs(sum([qexp_y[i]*qspec^i for i in range(floor(bigo*0.95),bigo-1)]))),50)
		return guess

	#function to find the maximum LLL-precision t when using a single tau
	def maxt(D):
		assert D<0 and (D%4==0 or D%4==1)
		assert gcd(N,D)==1 and Zmod(N)(D).is_square()
		d = D.squarefree_part()
		if d%4==3 or d%4==2:
			d*=4
		u = sqrt(D/d)
		o = ZZ[u*(d+sqrt(d))/2]
		h = o.class_number()
		a = 1
		b = ZZ(Zmod(4*a*N)(D).sqrt())
		c = (b^2-D)/4
		KK.<delta> = QuadraticField(D)
		sqrtD = KK(D).sqrt()
		alpha = (-b + sqrtD)/(2*a)
		tau = alpha/N
		qspec = C(exp(2*pi*I*tau))
		xp = qexp_x(qspec)
		yp = qexp_y(qspec)    
		knownbits = min(floor(log(1/guesserror(tau))/log(2)),bitp) #assumes implicitly that x and y have modulus at least one
		largestterm = log(max(abs(Q(xp,yp)),1)^(floor(h/3)+1)*max(abs(R(xp,yp)),1)*max(abs(S(xp,yp)),1))/log(2) #bit size of largest monomial (excluding coefficient) in the class polynomial
		diff = knownbits - largestterm
		return floor(LLLper/100*diff*log(2)/log(10))

if N == 239:
	fb = Newforms(N,names='beta')[0]
	F = fb.base_ring()
	bigo = 10000
	f = fb.q_expansion(bigo)
	beta = f[2]
	K.<q> = Frac(QQ[['q']])
	f1 = sum([(f[i][0]+(beta*f[i])[0])*q^i for i in range(bigo)]) + O(q^bigo)
	f3 = sum([-(beta*f[i])[0]*q^i for i in range(bigo)]) + O(q^bigo)
	f2 = sum([(beta^2*f[i])[0]*q^i for i in range(bigo)]) + O(q^bigo)
	Xp = f1/f3
	Yp = f2/f3
	R1.<x0,y0> = PolynomialRing(QQ)

	#From Magma
	P = x0^2-(y0+1)*x0-y0^2
	Q = y0*P-x0
	R = y0*Q-3*x0-2*y0
	S = y0*R-9*x0-4*y0

	#Optimizing P Q R S
	P = P
	Q = Q - 2*P
	R = R - 3*Q - 6*P
	S = S - 4*R - 10*Q - 19*P

	bitp = 20000
	C = ComplexField(bitp)
	I = C.gen()
	qexp_x = Xp.laurent_polynomial()
	qexp_y = Yp.laurent_polynomial()

	R2.<x1,x2,x3,x4> = PolynomialRing(QQ)

	#function to find a ZZ-relation using a single q
	def findzzrelmanual(h,qspec,xp,yp,t):
		maplist = [x1^0]
		for j in range(floor(h/3)+1):
			maplist += [x1^(j+1),x1^j*x2,x1^j*x3,x1^j*x4]
		del maplist[h+1:]
		Peval = P(xp,yp)
		Qeval = Q(xp,yp)
		Reval = R(xp,yp)
		Seval = S(xp,yp)
		qrslist = [m(Peval,Qeval,Reval,Seval) for m in maplist]
		A = Matrix(ZZ,[[int(i==j) for i in range(h+1)]+[round(10^t*real(qrslist[j])),round(10^t*imag(qrslist[j]))] for j in range(h+1)])
		shortvector = A.LLL()[0]
		zzrel = vector(QQ,shortvector[:h+1]).inner_product(vector(R2,maplist))
		error = shortvector[-2:]
		return zzrel,error

	#function to find a ZZ-relation using a single (the highest) tau
	def disctopolysingle(D,t):
		assert D<0 and (D%4==0 or D%4==1)
		assert gcd(N,D)==1 and Zmod(N)(D).is_square()
		d = D.squarefree_part()
		if d%4==3 or d%4==2:
			d*=4
		u = sqrt(D/d)
		o = ZZ[u*(d+sqrt(d))/2]
		h = o.class_number()
		a = 1
		b = ZZ(Zmod(4*a*N)(D).sqrt())
		c = (b^2-D)/4
		KK.<delta> = QuadraticField(D)
		sqrtD = KK(D).sqrt()
		alpha = (-b + sqrtD)/(2*a)
		tau = alpha/N
		qspec = C(exp(2*pi*I*tau))
		xp = qexp_x(qspec)
		yp = qexp_y(qspec)
		zzrel,error = findzzrelmanual(h,qspec,xp,yp,t)
		return [h,u,D,zzrel,error,t]

	#function to compute the "improvement factor" for a given D and LLL-precision t
	def compare(D,t):
		data = disctopolysingle(D,t)
		h = data[0]
		class_polynomial = data[3]
		maxhilbert = max([abs(hilbert_class_polynomial(D)[i]) for i in range(h+1)])
		maxclass = max([abs(i[0]) for i in list(class_polynomial)]+[2]) # +[2] to make sure we don't divide by zero
		improvementfactor = n(log(maxhilbert)/log(maxclass),20)
		return data+[improvementfactor]

	#function to estimate tail of the q-expansion of Xp
	def guesserror(tau):
		qspec = C(exp(2*pi*I*tau))
		guess = n(max(abs(sum([qexp_x[i]*qspec^i for i in range(floor(bigo*0.95),bigo-1)])),abs(sum([qexp_y[i]*qspec^i for i in range(floor(bigo*0.95),bigo-1)]))),50)
		return guess

	#function to find the maximum LLL-precision t when using a single tau
	def maxt(D):
		assert D<0 and (D%4==0 or D%4==1)
		assert gcd(N,D)==1 and Zmod(N)(D).is_square()
		d = D.squarefree_part()
		if d%4==3 or d%4==2:
			d*=4
		u = sqrt(D/d)
		o = ZZ[u*(d+sqrt(d))/2]
		h = o.class_number()
		a = 1
		b = ZZ(Zmod(4*a*N)(D).sqrt())
		c = (b^2-D)/4
		KK.<delta> = QuadraticField(D)
		sqrtD = KK(D).sqrt()
		alpha = (-b + sqrtD)/(2*a)
		tau = alpha/N
		qspec = C(exp(2*pi*I*tau))
		xp = qexp_x(qspec)
		yp = qexp_y(qspec)    
		knownbits = min(floor(log(1/guesserror(tau))/log(2)),bitp) #assumes implicitly that x and y have modulus at least one
		largestterm = log(max(abs(P(xp,yp)),1)^(floor(h/4)+1)*max(abs(Q(xp,yp)),abs(R(xp,yp)),abs(S(xp,yp)),1))/log(2) #bit size of largest monomial (excluding coefficient) in the class polynomial
		diff = knownbits - largestterm
		return floor(LLLper/100*diff*log(2)/log(10))


#generate class polynomials for suitable discriminants
print(firstline)
op = open(filestr, 'w')
op.write(firstline)
op.close()
D=lowdisc+1
for i in range(lowdisc-highdisc):
    D -= 1
    if D<0 and (D%4==0 or D%4==1) and gcd(N,D)==1 and Zmod(N)(D).is_square():
        d = D.squarefree_part()
        if d%4==3 or d%4==2:
            d*=4
        u = sqrt(D/d)
        if u == 1:
            o = ZZ[u*(d+sqrt(d))/2]
            h = o.class_number()
            if h.is_prime() and h>=lowclass and h<=highclass:
                print('Current discriminant:',D,'class number =',h)
                datum = compare(D,maxt(D))
                with open(filestr, 'a') as op:
                    op.write(str(datum)+'\n')
                    op.close()
