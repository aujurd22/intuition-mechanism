#Computing the generalized class polynomials for X_0^+(119) for N|D.

N = 119

lowdisc = -1000
highdisc = -30000000
discrange = range(lowdisc,highdisc,-1)

lowclass = 1
highclass = 150

LLLper = 80

bitp = 20000
C = ComplexField(bitp)
I = C.gen()
K.<q> = Frac(QQ[['q']])
R2.<r,s> = PolynomialRing(QQ)

bigo = 2600
load("xy2600.sage")

qexp_y = -qexp_y-2*qexp_x

#function to find a ZZ-relation using a single q
def findzzrelmanual(h,qspec,xp,yp,t):
    maplist = [r^0]
    for j in range(floor(h/2)+1):
        maplist += [r^(j+1),r^j*s]
    del maplist[(floor((h+1)/2)+2):]
    qrslist = [m(xp,yp) for m in maplist]
    A = Matrix(ZZ,[[int(i==j) for i in range((floor((h+1)/2)+2))]+[round(10^t*real(qrslist[j])),round(10^t*imag(qrslist[j]))] for j in range((floor((h+1)/2)+2))])
    shortvector = A.LLL()[0]
    zzrel = vector(QQ,shortvector[:(floor((h+1)/2)+2)]).inner_product(vector(R2,maplist))
    error = shortvector[-2:]
    return zzrel,error

#function to find a ZZ-relation using a single (the highest) tau
def disctopolysingle(D,t):
    assert D<0 and (D%4==0 or D%4==1)
    d = D.squarefree_part()
    if d%4==3 or d%4==2:
        d*=4
    u = sqrt(D/d)
    o = ZZ[u*(d+sqrt(d))/2]
    h = o.class_number()
    a = 1
    b = ZZ(Zmod(4*a*N)(D).sqrt())
    c = (b^2-D)/4
    KK.<delta> = QuadraticField(D)
    sqrtD = KK(D).sqrt()
    alpha = (-b + sqrtD)/(2*a)
    tau = alpha/N
    qspec = C(exp(2*pi*I*tau))
    xp = (qexp_x.laurent_polynomial())(qspec)
    yp = (qexp_y.laurent_polynomial())(qspec)
    zzrel,error = findzzrelmanual(h,qspec,xp,yp,t)
    print(factor(zzrel))
    return [h,u,D,zzrel,error,t]

#function to compute the "improvement factor" for a given D and LLL-precision t
def compare(D,t):
    data = disctopolysingle(D,t)
    h = data[0]
    class_polynomial = data[3]
    maxhilbert = max([abs(hilbert_class_polynomial(D)[i]) for i in range(h+1)])
    maxclass = max([abs(i[0]) for i in list(class_polynomial)]+[2]) # +[2] to make sure we don't divide by zero
    improvementfactor = n(log(maxhilbert)/log(maxclass),20)
    return data+[improvementfactor]

#function to estimate tail of the q-expansion
def guesserror(tau):
    qspec = C(exp(2*pi*I*tau))
    guess = n(max(abs(sum([qexp_x[i]*qspec^i for i in range(floor(bigo*0.95),bigo-1)])),abs(sum([qexp_y[i]*qspec^i for i in range(floor(bigo*0.95),bigo-1)]))),50)
    return guess

#combination of the above two functions to estimate the maximum LLL-precision t when using a single tau
def maxt(D):
    assert D<0 and (D%4==0 or D%4==1)
    d = D.squarefree_part()
    if d%4==3 or d%4==2:
        d*=4
    u = sqrt(D/d)
    O = ZZ[u*(d+sqrt(d))/2]
    h = O.class_number()
    a = 1
    b = ZZ(Zmod(4*a*N)(D).sqrt())
    c = (b^2-D)/4
    KK.<delta> = QuadraticField(D)
    sqrtD = KK(D).sqrt()
    alpha = (-b + sqrtD)/(2*a)
    tau = alpha/N
    qspec = C(exp(2*pi*I*tau))
    knownbits = min(floor(log(1/guesserror(tau))/log(2)),bitp) #assumes implicitly that x and y have modulus at least one
    largestterm = log(max(abs((qexp_x.laurent_polynomial())(qspec)^(h/2)),1)*max(abs((qexp_y.laurent_polynomial())(qspec)),1))/log(2) #bit size of largest monomial (excluding coefficient) in the class polynomial
    diff = knownbits - largestterm
    return floor(LLLper/100*diff*log(2)/log(10))

data = []
D=lowdisc+1
for i in range(lowdisc-highdisc):
    D -= 1
    if D<0 and (D%4==0 or D%4==1) and D%N==0:
        d = D.squarefree_part()
        if d%4==3 or d%4==2:
            d*=4
        u = sqrt(D/d)
        if gcd(u,N) == 1:
            o = ZZ[u*(d+sqrt(d))/2]
            h = o.class_number()
            if h>=lowclass and h<=highclass:
                print('Current discriminant:',D,'class number =',h)
                datum = compare(D,maxt(D))
                data.append(datum)

list_plot([[d[0],d[6]] for d in data])

op = open('divides119h150t80all.txt','w')
op.write(str(data))
op.close()