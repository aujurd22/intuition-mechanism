import Mathlib

/-!
# A parity lemma for natural numbers

For every `n : ℕ`, `2 * n` is even and `n + (n + 1)` is odd.
-/

namespace RequestProject

/-- For every natural number `n`, `2 * n` is even and `n + (n + 1)` is odd. -/
theorem two_mul_even_and_add_succ_odd (n : ℕ) :
    Even (2 * n) ∧ Odd (n + (n + 1)) := by
  constructor
  · -- `2 * n = n + n`, which is exactly the definition of `Even`.
    exact ⟨n, by omega⟩
  · -- `2` does not divide `n + (n + 1) = 2 * n + 1`, so its remainder mod 2 is `1`.
    have hndvd : ¬ 2 ∣ n + (n + 1) := by omega
    have hmod : (n + (n + 1)) % 2 = 1 := Nat.two_dvd_ne_zero.mp hndvd
    exact Nat.odd_iff.mpr hmod

end RequestProject
